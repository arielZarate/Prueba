alert("Hola world");

console.log("Hola mundo");